EasyLock Website — Local Setup
=============================

Open:
1) Unzip the folder
2) Open index.html in your browser

Included:
- index.html
- styles.css
- script.js
- assets/ (logo, favicon, creators, research graphics)

Contact:
ornsteinj27@goastudent.org
